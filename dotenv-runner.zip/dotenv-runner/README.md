# DotEnv Runner (IntelliJ Platform Plugin)

Load environment variables from selected files, grouped into profiles. Supports:
- `.env` (dotenv)
- `.properties`
- JSON in two modes: **JSON_FLAT** (flattened a.b.c=value) and **JSON_AS_VALUE** (filename/content under a single key).

## Highlights
- Profiles with **ordered files** (last wins on key conflicts).
- Per-Run-Configuration override; otherwise project default profile.
- Status bar widget and toolbar dropdown for **quick switching**.
- Master on/off toggle; optional "preserve existing env".
- **Separate from Spring**: by default, blocks `SPRING_PROFILES_ACTIVE` keys and never touches `-Dspring.profiles.active`.

## Build & Run
```bash
./gradlew runIde        # launches sandbox IDE for testing
./gradlew buildPlugin   # creates ZIP in build/distributions
```

## Install
- In IntelliJ: **Settings → Plugins → ⚙ → Install Plugin from Disk…** and choose the zip.

## Notes
- Settings are stored locally in `.idea/` (workspace), not shared in VCS.
- Console banner is optional and not Spring-specific.