package dev.arun.dotenvrunner

import com.intellij.openapi.project.Project
import com.intellij.openapi.wm.StatusBarWidget
import com.intellij.openapi.wm.StatusBarWidgetFactory
import com.intellij.openapi.wm.StatusBar
import com.intellij.ui.ClickListener
import java.awt.event.MouseEvent
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.JComponent

class DotEnvStatusBarFactory : StatusBarWidgetFactory {
  override fun getId(): String = "DotEnvProfileStatus"
  override fun getDisplayName(): String = "DotEnv Active Profile"
  override fun isAvailable(project: Project): Boolean = true
  override fun createWidget(project: Project): StatusBarWidget = DotEnvStatusBarWidget(project)
  override fun disposeWidget(widget: StatusBarWidget) {}
  override fun canBeEnabledOn(statusBar: StatusBar): Boolean = true
}

class DotEnvStatusBarWidget(private val project: Project) : StatusBarWidget, StatusBarWidget.TextPresentation {
  private var statusBar: StatusBar? = null

  override fun ID(): String = "DotEnvProfileStatus"
  override fun getPresentation(): StatusBarWidget.WidgetPresentation = this
  override fun install(statusBar: StatusBar) { this.statusBar = statusBar }
  override fun dispose() { }

  override fun getText(): String {
    val s = DotEnvSettings.getInstance(project).state
    return "DotEnv: ${s.defaultProfile}"
  }
  override fun getAlignment(): Float = 0.5f
  override fun getTooltipText(): String = "Active DotEnv profile"
  override fun getClickConsumer(): ((MouseEvent) -> Unit)? = { _ ->
    // cycle through profiles on click
    val st = DotEnvSettings.getInstance(project).state
    val names = st.profiles.map { it.name }
    if (names.isEmpty()) return@getClickConsumer
    val idx = names.indexOf(st.defaultProfile).coerceAtLeast(0)
    val next = names[(idx + 1) % names.size]
    st.defaultProfile = next
    statusBar?.updateWidget(ID())
  }
}