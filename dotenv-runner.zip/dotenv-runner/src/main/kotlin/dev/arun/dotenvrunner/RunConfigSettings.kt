package dev.arun.dotenvrunner

import com.intellij.openapi.components.*
import com.intellij.openapi.project.Project

@State(name = "DotEnvRunConfig", storages = [Storage(StoragePathMacros.WORKSPACE_FILE)])
class DotEnvRunConfigService : PersistentStateComponent<DotEnvRunConfigService.State> {
  data class State(var profilePerConfig: MutableMap<String, String> = mutableMapOf())
  private var s = State()
  override fun getState() = s
  override fun loadState(state: State) { s = state }
  companion object { fun getInstance(project: Project) = project.getService(DotEnvRunConfigService::class.java) }
}