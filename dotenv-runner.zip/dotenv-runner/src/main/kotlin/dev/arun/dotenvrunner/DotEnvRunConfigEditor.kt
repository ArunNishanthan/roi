package dev.arun.dotenvrunner

import com.intellij.execution.configurations.RunConfigurationBase
import com.intellij.openapi.options.SettingsEditor
import javax.swing.*

class DotEnvRunConfigEditor : SettingsEditor<RunConfigurationBase<*>>() {
  private val profileCombo = JComboBox<String>()
  private val label = JLabel("DotEnv profile: ")

  override fun createEditor(): JComponent = JPanel().apply {
    layout = BoxLayout(this, BoxLayout.X_AXIS)
    add(label); add(Box.createHorizontalStrut(8)); add(profileCombo)
  }

  override fun resetEditorFrom(s: RunConfigurationBase<*>) {
    val settings = DotEnvSettings.getInstance(s.project)
    profileCombo.model = DefaultComboBoxModel(settings.state.profiles.map { it.name }.toTypedArray())
    val svc = DotEnvRunConfigService.getInstance(s.project)
    profileCombo.selectedItem = svc.state.profilePerConfig[s.dotenvKey()] ?: settings.state.defaultProfile
  }

  override fun applyEditorTo(s: RunConfigurationBase<*>) {
    val svc = DotEnvRunConfigService.getInstance(s.project)
    svc.state.profilePerConfig[s.dotenvKey()] = profileCombo.selectedItem?.toString() ?: return
  }
}