package dev.arun.dotenvrunner

import com.intellij.execution.configurations.GeneralCommandLine
import com.intellij.execution.configurations.RunConfigurationBase
import com.intellij.execution.runners.ExecutionEnvironment
import com.intellij.execution.RunConfigurationExtension
import com.intellij.openapi.diagnostic.Logger

class DotEnvRunConfigurationExtension : RunConfigurationExtension() {
  private val log = Logger.getInstance(DotEnvRunConfigurationExtension::class.java)

  override fun isApplicableFor(configuration: RunConfigurationBase<*>): Boolean = true
  override fun getEditorTitle(): String = "DotEnv"
  override fun <T : RunConfigurationBase<*>> isApplicableFor(configuration: T, runnerId: String?): Boolean = true

  override fun <T : RunConfigurationBase<*>> patchCommandLine(
    configuration: T,
    runnerSettings: com.intellij.execution.configurations.RunProfileState?,
    cmdLine: GeneralCommandLine,
    runnerId: String?,
    environment: ExecutionEnvironment?
  ) {
    val project = configuration.project
    val settings = DotEnvSettings.getInstance(project)
    if (!settings.state.enabled) return

    val runSvc = DotEnvRunConfigService.getInstance(project)
    val chosenProfileName = runSvc.state.profilePerConfig[configuration.dotenvKey()] ?: settings.state.defaultProfile
    val profile = settings.state.profiles.firstOrNull { it.name == chosenProfileName } ?: return

    val envFromFilesRaw = EnvLoader.loadForProfile(project, profile)
    val filtered = EnvGuards.filter(envFromFilesRaw, settings.state.ignoreSpringProfiles)
    val withProfile = LinkedHashMap(filtered).apply { putIfAbsent("DOTENV_PROFILE", profile.name) }

    val envs = cmdLine.environment
    val merged = LinkedHashMap<String, String>()
    if (settings.state.preserveExisting) merged.putAll(envs)
    merged.putAll(withProfile)
    if (!settings.state.preserveExisting) merged.putAll(envs)

    cmdLine.environment.clear()
    cmdLine.environment.putAll(merged)

    if (settings.state.logApplied) {
      log.info("DotEnv Runner injected ${filtered.size} vars from ${profile.files.size} files (profile=${profile.name})")
    }
  }
}