package dev.arun.dotenvrunner

import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.project.Project
import com.intellij.openapi.vfs.VfsUtil
import com.intellij.openapi.vfs.VirtualFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

object DotEnv {
  private val log = Logger.getInstance(DotEnv::class.java)

  /**
   * Pragmatic .env loader:
   * - Ignores full-line comments (#)
   * - Supports 'export KEY=...'
   * - Supports single/double quotes
   * - Unescapes \n, \t, \r and \\
   */
  fun load(project: Project, path: String?): Map<String, String> {
    val vf = resolveEnvFile(project, path) ?: return emptyMap()
    val map = LinkedHashMap<String, String>()

    try {
      BufferedReader(InputStreamReader(vf.inputStream, StandardCharsets.UTF_8)).use { br ->
        br.lineSequence().forEach { raw ->
          var line = raw.trim()
          if (line.isEmpty()) return@forEach
          if (line.startsWith("#")) return@forEach

          val hasQuote = line.contains('"') || line.contains('\'')
          if (!hasQuote) {
            val hash = line.indexOf('#')
            if (hash >= 0) line = line.substring(0, hash).trim()
          }

          val eq = line.indexOf('=')
          if (eq <= 0) return@forEach

          var key = line.substring(0, eq).trim()
          var value = line.substring(eq + 1).trim()

          if (key.startsWith("export ")) key = key.removePrefix("export ").trim()

          if ((value.startsWith("\"") && value.endsWith("\"")) ||
              (value.startsWith("'") && value.endsWith("'"))) {
            value = value.substring(1, value.length - 1)
          }

          value = value
            .replace("\\n", "\n")
            .replace("\\t", "\t")
            .replace("\\r", "\r")
            .replace("\\\\", "\\")

          if (key.isNotBlank()) map[key] = value
        }
      }
    } catch (t: Throwable) {
      log.warn("Failed to read .env: ${t.message}")
    }
    return map
  }

  private fun resolveEnvFile(project: Project, pathFromSettings: String?): VirtualFile? {
    val path = pathFromSettings?.takeIf { it.isNotBlank() } ?: ".env"
    val base = project.baseDir ?: return null
    return VfsUtil.findRelativeFile(path, base)
  }
}