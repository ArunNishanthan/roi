package dev.arun.dotenvrunner

import com.intellij.execution.configurations.RunConfigurationBase

fun RunConfigurationBase<*>.dotenvKey(): String = "${project.name}:${name}:${type.id}"