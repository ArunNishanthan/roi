package dev.arun.dotenvrunner

object EnvGuards {
  private val blockedExact = setOf("SPRING_PROFILES_ACTIVE", "spring.profiles.active")

  fun filter(map: Map<String, String>, ignoreSpringProfiles: Boolean): Map<String, String> {
    if (!ignoreSpringProfiles) return map
    return map.filterKeys { k -> !blockedExact.contains(k) }
  }
}