package dev.arun.dotenvrunner

import com.intellij.openapi.actionSystem.*
import com.intellij.openapi.project.DumbAware
import javax.swing.*

class ProfileComboAction : ComboBoxAction(), DumbAware {
  override fun createPopupActionGroup(button: JComponent, dataContext: DataContext): DefaultActionGroup {
    val project = CommonDataKeys.PROJECT.getData(dataContext) ?: return DefaultActionGroup()
    val settings = DotEnvSettings.getInstance(project).state
    val group = DefaultActionGroup()
    settings.profiles.forEach { profile ->
      group.add(object : AnAction(profile.name) {
        override fun actionPerformed(e: AnActionEvent) {
          settings.defaultProfile = profile.name
          // No explicit UI to update here; status bar widget shows change
        }
      })
    }
    return group
  }

  override fun update(e: AnActionEvent) {
    val project = e.project
    if (project == null) {
      e.presentation.isEnabledAndVisible = false
      return
    }
    val settings = DotEnvSettings.getInstance(project).state
    e.presentation.text = "Profile: ${settings.defaultProfile}"
    e.presentation.isEnabledAndVisible = true
  }
}