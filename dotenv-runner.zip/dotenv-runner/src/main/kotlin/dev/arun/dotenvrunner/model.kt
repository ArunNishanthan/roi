package dev.arun.dotenvrunner

enum class FileType { ENV, PROPERTIES, JSON_FLAT, JSON_AS_VALUE }

data class FileEntry(
  var path: String = ".env",
  var type: FileType = FileType.ENV,
  var jsonAsValueKey: String? = null, // when JSON_AS_VALUE, override key else derive from filename
  var prefix: String? = null          // optional key prefix (e.g., "APP_")
)

data class Profile(
  var name: String = "default",
  var files: MutableList<FileEntry> = mutableListOf()
)