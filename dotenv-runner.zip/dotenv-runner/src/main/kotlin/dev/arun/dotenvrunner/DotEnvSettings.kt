package dev.arun.dotenvrunner

import com.intellij.openapi.components.PersistentStateComponent
import com.intellij.openapi.components.State
import com.intellij.openapi.components.Storage
import com.intellij.openapi.project.Project

@State(name = "DotEnvSettings", storages = [Storage("dotenv-runner.xml")])
class DotEnvSettings(private val project: Project) : PersistentStateComponent<DotEnvSettings.State> {

  data class State(
    var enabled: Boolean = true,
    var preserveExisting: Boolean = false,
    var logApplied: Boolean = false,
    var defaultProfile: String = "default",
    var profiles: MutableList<Profile> = mutableListOf(Profile("default", mutableListOf(FileEntry(path = ".env", type = FileType.ENV)))),
    var ignoreSpringProfiles: Boolean = true
  )

  private var myState = State()

  override fun getState(): State = myState
  override fun loadState(state: State) { myState = state }

  companion object {
    fun getInstance(project: Project): DotEnvSettings = project.getService(DotEnvSettings::class.java)
  }
}