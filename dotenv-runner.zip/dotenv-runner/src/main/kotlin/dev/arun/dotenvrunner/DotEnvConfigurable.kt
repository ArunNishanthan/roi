package dev.arun.dotenvrunner

import com.intellij.openapi.options.Configurable
import com.intellij.openapi.project.Project
import com.intellij.ui.ToolbarDecorator
import com.intellij.ui.components.JBCheckBox
import com.intellij.ui.components.JBLabel
import com.intellij.ui.table.TableView
import com.intellij.util.ui.ColumnInfo
import com.intellij.util.ui.FormBuilder
import com.intellij.util.ui.ListTableModel
import java.awt.BorderLayout
import java.awt.Component
import javax.swing.*
import javax.swing.table.TableCellEditor
import javax.swing.table.TableCellRenderer

class DotEnvConfigurable(private val project: Project) : Configurable {
  private val settings get() = DotEnvSettings.getInstance(project)

  private val enable = JBCheckBox("Enable environment injection")
  private val preserve = JBCheckBox("Preserve existing env over file values")
  private val logApplied = JBCheckBox("Log applied variable names (not values)")
  private val ignoreSpring = JBCheckBox("Ignore Spring profile keys (recommended)")

  // Profiles list
  private val profilesModel = DefaultListModel<Profile>()
  private val profilesList = JList(profilesModel).apply {
    selectionMode = ListSelectionModel.SINGLE_SELECTION
    cellRenderer = object : DefaultListCellRenderer() {
      override fun getListCellRendererComponent(list: JList<*>, value: Any?, index: Int, isSelected: Boolean, cellHasFocus: Boolean): Component {
        val c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus) as JLabel
        val p = value as Profile
        c.text = p.name
        return c
      }
    }
  }

  private val defaultProfileCombo = JComboBox<String>()

  // Files table for the selected profile
  private val filesModel = ListTableModel<FileEntry>(
    object : ColumnInfo<FileEntry, String>("Path") {
      override fun valueOf(item: FileEntry) = item.path
      override fun isCellEditable(item: FileEntry) = true
      override fun setValue(item: FileEntry, value: String) { item.path = value }
      override fun getColumnClass(): Class<*> = String::class.java
    },
    object : ColumnInfo<FileEntry, FileType>("Type") {
      override fun valueOf(item: FileEntry) = item.type
      override fun isCellEditable(item: FileEntry) = true
      override fun setValue(item: FileEntry, value: FileType) { item.type = value }
      override fun getColumnClass(): Class<*> = FileType::class.java
      override fun getEditor(item: FileEntry): TableCellEditor = DefaultCellEditor(JComboBox(FileType.values()))
      override fun getRenderer(item: FileEntry?): TableCellRenderer = DefaultTableCellRenderer().apply { horizontalAlignment = SwingConstants.LEFT }
    },
    object : ColumnInfo<FileEntry, String>("Prefix") {
      override fun valueOf(item: FileEntry) = item.prefix ?: ""
      override fun isCellEditable(item: FileEntry) = true
      override fun setValue(item: FileEntry, value: String) { item.prefix = value.ifBlank { null } }
      override fun getColumnClass(): Class<*> = String::class.java
    },
    object : ColumnInfo<FileEntry, String>("JSON key (AS_VALUE)") {
      override fun valueOf(item: FileEntry) = item.jsonAsValueKey ?: ""
      override fun isCellEditable(item: FileEntry) = true
      override fun setValue(item: FileEntry, value: String) { item.jsonAsValueKey = value.ifBlank { null } }
      override fun getColumnClass(): Class<*> = String::class.java
    }
  )
  private val filesTable = TableView(filesModel).apply { setShowGrid(false) }

  private val filesPanel: JComponent = ToolbarDecorator.createDecorator(filesTable)
    .setAddAction {
      val p = selectedProfile() ?: return@setAddAction
      val entry = FileEntry(path = ".env", type = FileType.ENV)
      p.files.add(entry); refreshFiles(p)
    }
    .setRemoveAction {
      val p = selectedProfile() ?: return@setRemoveAction
      val idx = filesTable.selectedRow
      if (idx in 0 until p.files.size) { p.files.removeAt(idx); refreshFiles(p) }
    }
    .setMoveUpAction {
      val p = selectedProfile() ?: return@setMoveUpAction
      val i = filesTable.selectedRow
      if (i > 0) { p.files.add(i - 1, p.files.removeAt(i)); refreshFiles(p); filesTable.selectionModel.setSelectionInterval(i - 1, i - 1) }
    }
    .setMoveDownAction {
      val p = selectedProfile() ?: return@setMoveDownAction
      val i = filesTable.selectedRow
      if (i >= 0 && i < p.files.size - 1) { p.files.add(i + 1, p.files.removeAt(i)); refreshFiles(p); filesTable.selectionModel.setSelectionInterval(i + 1, i + 1) }
    }
    .addExtraAction(object : com.intellij.ui.AnActionButton("Choose File", null, com.intellij.icons.AllIcons.Actions.Menu_open) {
      override fun actionPerformed(e: com.intellij.openapi.actionSystem.AnActionEvent) {
        val p = selectedProfile() ?: return
        val idx = filesTable.selectedRow.takeIf { it >= 0 } ?: return
        val entry = p.files[idx]
        val chooser = com.intellij.openapi.fileChooser.FileChooserDescriptor(true, false, false, false, false, false)
        val vfile = com.intellij.openapi.fileChooser.FileChooser.chooseFile(chooser, project, project.baseDir) ?: return
        entry.path = com.intellij.openapi.vfs.VfsUtilCore.getRelativePath(vfile, project.baseDir!!) ?: vfile.path
        filesTable.repaint()
      }
    })
    .createPanel()

  private val profilesPanel: JComponent = ToolbarDecorator.createDecorator(profilesList)
    .setAddAction {
      val name = JOptionPane.showInputDialog("New profile name:")?.trim().orEmpty()
      if (name.isNotEmpty() && profilesModel.elements().asIterator().asSequence().none { it.name == name }) {
        profilesModel.addElement(Profile(name, mutableListOf()))
        rebuildDefaultProfileCombo()
      }
    }
    .setRemoveAction {
      val idx = profilesList.selectedIndex
      if (idx >= 0) {
        val removing = profilesModel.get(idx)
        profilesModel.remove(idx)
        if (defaultProfileCombo.selectedItem == removing.name) {
          defaultProfileCombo.selectedItem = profilesModel.firstElement()?.name ?: "default"
        }
        refreshFiles(selectedProfile())
        rebuildDefaultProfileCombo()
      }
    }
    .setEditAction {
      val i = profilesList.selectedIndex
      if (i >= 0) {
        val current = profilesModel.get(i)
        val newName = JOptionPane.showInputDialog("Rename profile:", current.name)?.trim().orEmpty()
        if (newName.isNotEmpty()) {
          profilesModel.set(i, current.copy(name = newName))
          rebuildDefaultProfileCombo()
          profilesList.repaint()
        }
      }
    }
    .createPanel()

  private val root = JPanel(BorderLayout())

  init {
    profilesList.addListSelectionListener { refreshFiles(selectedProfile()) }

    val top = FormBuilder.createFormBuilder()
      .addComponent(enable)
      .addComponent(preserve)
      .addComponent(logApplied)
      .addComponent(ignoreSpring)
      .addLabeledComponent(JBLabel("Default profile:"), defaultProfileCombo, 1, false)
      .panel

    val split = JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
      JPanel(BorderLayout()).apply {
        border = BorderFactory.createTitledBorder("Profiles")
        add(profilesPanel, BorderLayout.CENTER)
      },
      JPanel(BorderLayout()).apply {
        border = BorderFactory.createTitledBorder("Files in selected profile (last wins)")
        add(filesPanel, BorderLayout.CENTER)
      }
    ).apply { resizeWeight = 0.25 }

    root.add(top, BorderLayout.NORTH)
    root.add(split, BorderLayout.CENTER)

    reset()
  }

  private fun selectedProfile(): Profile? = profilesList.selectedValue

  private fun refreshFiles(profile: Profile?) {
    val rows = profile?.files ?: mutableListOf()
    filesModel.setItems(rows)
    filesTable.tableHeader?.repaint()
  }

  private fun rebuildDefaultProfileCombo() {
    defaultProfileCombo.model = DefaultComboBoxModel(profilesModel.elements().asIterator().asSequence().map { it.name }.toList().toTypedArray())
  }

  override fun getDisplayName(): String = "DotEnv Runner"
  override fun createComponent(): JComponent = root

  override fun isModified(): Boolean {
    val s = settings.state
    val uiProfiles = profilesModel.elements().asIterator().asSequence().toList()
    val sameProfiles = uiProfiles.size == s.profiles.size && uiProfiles.zip(s.profiles).all { (a,b) -> a.name == b.name && a.files == b.files }
    return enable.isSelected != s.enabled ||
           preserve.isSelected != s.preserveExisting ||
           logApplied.isSelected != s.logApplied ||
           ignoreSpring.isSelected != s.ignoreSpringProfiles ||
           (defaultProfileCombo.selectedItem?.toString() ?: "") != s.defaultProfile ||
           !sameProfiles
  }

  override fun apply() {
    val s = settings.state
    s.enabled = enable.isSelected
    s.preserveExisting = preserve.isSelected
    s.logApplied = logApplied.isSelected
    s.ignoreSpringProfiles = ignoreSpring.isSelected
    s.defaultProfile = defaultProfileCombo.selectedItem?.toString() ?: s.defaultProfile
    s.profiles = profilesModel.elements().asIterator().asSequence().map { it.copy(files = it.files.toMutableList()) }.toMutableList()
  }

  override fun reset() {
    val s = settings.state
    enable.isSelected = s.enabled
    preserve.isSelected = s.preserveExisting
    logApplied.isSelected = s.logApplied
    ignoreSpring.isSelected = s.ignoreSpringProfiles

    profilesModel.clear()
    s.profiles.forEach { profilesModel.addElement(it.copy(files = it.files.toMutableList())) }
    profilesList.selectedIndex = s.profiles.indexOfFirst { it.name == s.defaultProfile }.coerceAtLeast(0)
    rebuildDefaultProfileCombo()
    defaultProfileCombo.selectedItem = s.defaultProfile

    refreshFiles(selectedProfile())
  }
}