package dev.arun.dotenvrunner

import com.intellij.execution.configurations.RunConfigurationExtensionBase
import com.intellij.execution.configurations.RunConfigurationBase
import com.intellij.openapi.options.SettingsEditor

class DotEnvRunConfigurationExtension2 : RunConfigurationExtensionBase<RunConfigurationBase<*>>() {
  override fun getEditorTitle() = "DotEnv"
  override fun createEditor(configuration: RunConfigurationBase<*>): SettingsEditor<RunConfigurationBase<*>> = DotEnvRunConfigEditor()
}