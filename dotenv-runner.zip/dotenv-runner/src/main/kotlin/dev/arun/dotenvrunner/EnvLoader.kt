package dev.arun.dotenvrunner

import com.intellij.openapi.project.Project
import com.intellij.openapi.vfs.VfsUtil
import java.nio.charset.Charset
import java.util.Properties
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.jetbrains.annotations.VisibleForTesting

object EnvLoader {

  fun loadForProfile(project: Project, profile: Profile): Map<String, String> {
    val result = LinkedHashMap<String, String>()
    for (entry in profile.files) {
      val file = VfsUtil.findRelativeFile(entry.path, project.baseDir) ?: continue
      val kv = when (entry.type) {
        FileType.ENV -> DotEnv.load(project, entry.path)
        FileType.PROPERTIES -> fromProperties(file)
        FileType.JSON_FLAT -> fromJsonFlat(file)
        FileType.JSON_AS_VALUE -> mapOf((entry.jsonAsValueKey ?: keyFromFilename(file.name)) to file.contents())
      }
      val withPrefix = entry.prefix?.takeIf { it.isNotEmpty() }?.let { p -> kv.mapKeys { (k, _) -> p + k } } ?: kv
      // last-wins
      for ((k, v) in withPrefix) result[k] = v
    }
    return result
  }

  private fun keyFromFilename(name: String) = name.substringBeforeLast('.')
  private fun com.intellij.openapi.vfs.VirtualFile.contents(cs: Charset = Charsets.UTF_8) = this.inputStream.reader(cs).readText()

  private fun fromProperties(file: com.intellij.openapi.vfs.VirtualFile): Map<String, String> {
    val p = Properties()
    file.inputStream.use { p.load(it) }
    return p.entries.associate { (k, v) -> k.toString() to v.toString() }
  }

  private fun fromJsonFlat(file: com.intellij.openapi.vfs.VirtualFile): Map<String, String> {
    val text = file.inputStream.reader(Charsets.UTF_8).readText()
    val any = jacksonObjectMapper().readValue(text, Any::class.java)
    val out = LinkedHashMap<String, String>()
    flattenJson(any, out, "")
    return out
  }

  @VisibleForTesting
  fun flattenJson(node: Any?, out: MutableMap<String, String>, prefix: String) {
    when (node) {
      is Map<*, *> -> node.forEach { (k, v) ->
        val key = if (prefix.isEmpty()) k.toString() else "$prefix.$k"
        flattenJson(v, out, key)
      }
      is Iterable<*> -> node.forEachIndexed { i, v -> flattenJson(v, out, "$prefix[$i]") }
      null -> if (prefix.isNotEmpty()) out[prefix] = "null"
      else -> if (prefix.isNotEmpty()) out[prefix] = node.toString()
    }
  }
}