plugins {
  id("org.jetbrains.intellij") version "1.17.3"
  kotlin("jvm") version "1.9.24"
}

repositories { mavenCentral() }

intellij {
  version.set("2024.1") // Adjust if your IDE baseline differs
  type.set("IC")        // Use "IU" for Ultimate
  plugins.set(listOf())
}

dependencies {
  implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.17.2")
}

tasks {
  patchPluginXml {
    sinceBuild.set("241")
    untilBuild.set(null as String?)
    changeNotes.set("Initial release with profiles, ordered files, .env/.properties/JSON support, status bar & toolbar switchers.")
  }

  runIde {
    jvmArgs("-Xmx2g")
  }
}

kotlin {
  jvmToolchain(17)
}